int main() {
    int i,j,k,sink, source;
// read source from input
    if (i > 1)
        j = source;
    else
        k = j;
    sink = k;
}

int main() {
    int i,j,k,sink, source;
// read source from user input or it can be
// initilized with a tainted value. e.g. source = 1234567
    i = source;
    if (j > 1)
        ;
    else
        k = i;
    sink = k;
}

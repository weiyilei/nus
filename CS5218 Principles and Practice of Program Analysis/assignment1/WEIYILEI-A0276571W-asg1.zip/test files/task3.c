int main() {
    int i,j,k=0,sink=0, source=1234567;
// read source from input or initilized with
// a tainted value. e.g. source = 1234567
    i=0;
    if (j > 1)
        i=source;
    else
        k = source;
    sink = i+k;
}

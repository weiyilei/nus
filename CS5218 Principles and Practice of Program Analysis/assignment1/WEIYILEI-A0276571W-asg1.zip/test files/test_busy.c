int main(){
    int a,b,x,y;
    if(a != b){
        x = b - a;
        y = a - b;
    }else{
        y = b - a;
        a = 0;
        x = a - b;
    }
}
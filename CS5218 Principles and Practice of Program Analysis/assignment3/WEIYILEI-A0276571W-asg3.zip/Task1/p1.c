#define TEAM_ID 4 // (substitute your team ID here 
#define N 10 // (N is statically fixed)
main() {
	int x = TEAM_ID;
	for (int i = 1; i <= N; i++) x += 1;
	if (x >= 0 && error(x))
		x = 1 / 0; // errorpoint
	printf("%d", x); 
}
int error(int x) { 
	return x == TEAM_ID + N || x == TEAM_ID + N + 1; 
} 

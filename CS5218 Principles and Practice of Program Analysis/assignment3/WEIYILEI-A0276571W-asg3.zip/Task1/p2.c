#define TEAM_ID 4 // (substitute your team ID here 
#define N 5
int error(int); 
int a[] = {1, 3, 5, 7, 9};
main() {
	int x = TEAM_ID, choice = 0;
	for (int i = 0; i < N; i++) {
		scanf("%d", &choice);
		if (choice) x += a[i];
	}
	if (error(x)) 
		x = 1 / 0; // error point 
	printf("%d", x); 
}
int error(int x) { 
	return x == TEAM_ID + 23 || x < 0;
} 

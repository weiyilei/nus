""" CS5229 Programming Assignment 1: 
    Sketch-based Network Monitoring

Name: 
Email: 
Student ID: 
"""

import numpy as np
from pympler import asizeof

class CountMinSketch:
    def __init__(self): #Allowed to add initialization parameters
        """Initialise the sketch. You may add additional variables to the function call.

            self.sketch: Variable to store the sketch
            self.auxiliary_storage: Additional auxiliary storage (optional)
        """

        self.sketch = ...  #Variable to store sketch
        self.auxiliary_storage = ...  # Variable to store heavy hitters (optional)

        """ YOUR CODE HERE
        TODO: Initialise the sketch with the required parameters
        """

        assert (asizeof.asizeof(self.sketch)+asizeof.asizeof(self.auxiliary_storage))/(1024**2) < 1, "Sketch Size is not less than 1 Megabyte"

    def hash_func(self, packet_flow, i = None):
        """Function handles the hashing functionality for the sketch

        Args:
            packet_flow: Tuple of (Source_IP, Destination_IP, Source_Port, Destination_Port, Protocol)
            i (optional): Optional arguement to specify the hash function ID to be used. Defaults to None.

        Returns:
            Hashed value of the packet_flow
        """

        """ YOUR CODE HERE
        TODO: Implement the hash functions
        """
        return 0    #Return the hashed value of the packet_flow
    
    def add_item(self, packet_flow, packet_len):
        """ Update sketch for the current packet in stream

        Args:
            packet_flow : Tuple of (Source_IP, Destination_IP, Source_Port, Destination_Port, Protocol)
            packet_len: Integer value of packet length
        """


        """ YOUR CODE HERE
        TODO: Implement the sketch update algorithm
        """
    
    def estimate_frequency(self, flow_X):
        """Estimate the frequency of flow_X using the sketch

        Args:
            flow_X: Tuple of (Source_IP, Destination_IP, Source_Port, Destination_Port, Protocol)

        Returns:
            Observed frequency of flow_X
        """

        ###### Task I - Freuqency Estimation ######
        flow_freq = 0 

        """ YOUR CODE HERE
        TODO: Implement the frequency estimation algorithm
        """

        return flow_freq 
    
    def count_unique_flows(self):
        """ Estimate the number of unique flows(Cardinality) using the sketch

        Returns:
            Cardinality of the packet trace
        """

        ###### Task II - Cardinality Estimation ######
        num_unique_flows = 0 
        
        """ YOUR CODE HERE
        TODO: Implement the cardinality estimation algorithm
        """
        return num_unique_flows
    
    def find_heavy_hitters(self):
        """ Find the heavy hitters using the sketch

        Returns:
            heavy_hitters: 5-Tuples representing the heavy hitter flows
            heavy_hitters_size: Size of the heavy hitter flows
        """
        ###### Task III - Heavy Hitter Detection ######
        heavy_hitters = []  # List to store heavy hitter flows
        heavy_hitters_size = []  # List to store heavy hitter sizes

        """ YOUR CODE HERE
        TODO: Implement the heavy hitter detection algorithm
        """
        
        return heavy_hitters, heavy_hitters_size